<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>View Bookings</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f5f7fa;
      padding: 30px;
      margin: 0;
    }

    h2 {
      text-align: center;
      color: #333;
      margin-bottom: 20px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      background: #fff;
      border-radius: 10px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
      overflow: hidden;
    }

    th, td {
      padding: 12px 15px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #007bff;
      color: white;
    }

    tr:hover {
      background-color: #f1f1f1;
    }

    .container {
      max-width: 800px;
      margin: auto;
    }

    a.button {
      display: inline-block;
      margin-top: 20px;
      padding: 10px 15px;
      background-color: #007bff;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      text-align: center;
    }

    a.button:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>All Hospital Checkup Bookings</h2>
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Name</th>
          <th>Phone</th>
          <th>Email</th>
          <th>Address</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($booking->id); ?></td>
            <td><?php echo e($booking->name); ?></td>
            <td><?php echo e($booking->phone); ?></td>
            <td><?php echo e($booking->email); ?></td>
            <td><?php echo e($booking->address); ?></td>
            <td>
                <form action="<?php echo e(route('bookings.destroy',$booking->id)); ?>" method="post" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" style="background-color:#dc3545; color:white; border:none; padding:5px 10px; border-radius:4px; cursor:pointer;">Delete</button>
                </form>

                <a href="<?php echo e(route('bookings.edit', $booking->id)); ?>" 
                   style="background-color:#28a745; color:white; border:none; padding:5px 10px; border-radius:4px; text-decoration:none; cursor:pointer; margin-left:5px;">
                   Edit
                </a>
            </td>
        </tr>     
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <a href="<?php echo e(route('bookings.create')); ?>" class="button">Add New Booking</a>
  </div>
</body>
</html>
<?php /**PATH C:\Users\HP 745 G5\Desktop\CRUD\resources\views/bookings/index.blade.php ENDPATH**/ ?>